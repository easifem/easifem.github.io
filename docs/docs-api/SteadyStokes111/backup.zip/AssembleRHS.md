# 𑗕 AssembleRHS

This procedure pointer assembles the right-hand-side vector.

## Interface

```fortran
INTERFACE
  MODULE SUBROUTINE AssembleRHS(obj)
    CLASS(SteadyStokes111_), INTENT(INOUT) :: obj
  END SUBROUTINE AssembleRHS
END INTERFACE
```

## Example

import EXAMPLE17 from "./_AssembleRHS_test_1.md";

<EXAMPLE17 />
