# SteadyStokes111

## Description of Kernel

- (1) Equal order interpolation for velocity and pressure field
- (1) Coupled linear system (dof=[u, p])
- (1) Constant material properties

Variational multiscale stabilization method is used, and following options are allowed

- SubscalePressure = True or False
- BoundarySubscale = True or False
- WeakDBC = True or False
- Multiphase = True or False

## TODO

- [ ] Body-force
- [ ] gravity
- [x] conservative and non-conservative form.
- [ ] Neumann boundary condition
- [ ] higher order terms
- [ ] Positive and negative sign in case of HOT
- [x] boundary subscale
- [x] pressure subscale
- [ ] no-slip boundary condition
- [ ] free-slip boundary condition
- [ ] inlet boundary condition
- [ ] outlet boundary-condition
- [ ] add an option to calculate stabilization parameter only at the center of the element
- [ ] handle quadrature mapping in general form
- [x] Add reference pressure node and pressure value.

## Ideas for optimization

- Constant stabilization parameter
- Better precondition for iterative solver

## Examples

Check the following examples in order:

- [SetSteadyStokes111Param](./_SetSteadyStokes111Param_test_1.md)
- [Initiate](./_Initiate_test_1.md)
- [AddFluidMaterial](./_AddFluidMaterial_test_1.md)
