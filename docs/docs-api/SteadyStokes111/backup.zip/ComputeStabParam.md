# 𑗕 ComputeStabParam

Compute stabilization parameter.

## Interface

```fortran
ABSTRACT INTERFACE
  SUBROUTINE SSF_ComputeStabParam(obj)
    IMPORT :: SteadyStokes111_
    CLASS(SteadyStokes111_), INTENT(INOUT) :: obj
  END SUBROUTINE SSF_ComputeStabParam
END INTERFACE
```

## Example

import EXAMPLE18 from "./_ComputeStabParam_test_1.md";

<EXAMPLE18 />
